import ARKit
import UIKit
import PlaygroundSupport
import Foundation

Controller.show2DScene(.menu, in: PlaygroundPage.current)
